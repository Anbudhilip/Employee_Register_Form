﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Task_2.Models;
using System.IO;

namespace Task_2.Controllers
{
    public class EmployeeController : Controller
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["emp_db"].ConnectionString);

        // GET: Employee
        public ActionResult Index()
        {
            try
            {
                SqlCommand sc = new SqlCommand("sp_fetch", conn);
                sc.CommandType = CommandType.StoredProcedure;
                conn.Open();
                SqlDataReader sdr = sc.ExecuteReader();


                List<Emp_Model> data = new List<Emp_Model>();
                while (sdr.Read())
                {
                    data.Add(new Emp_Model
                    {

                        emp_id = Convert.ToInt32(sdr["emp_id"]),
                        emp_name = sdr["emp_name"].ToString(),
                        emp_dob = sdr["emp_dob"].ToString(),
                        emp_email = sdr["emp_email"].ToString(),
                        emp_img = sdr["emp_img"].ToString()
                    });
                }
                return View(data);
            }
            catch (Exception ex)
            {
                TempData["msg"] = "Error:" + ex;
                return View("Create");
            }
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Emp_Model obj)
        {
            try
            {
                if (obj.emp_id == 0)
                {
                    string fileName = Path.GetFileNameWithoutExtension(obj.ImageFile.FileName);
                    string extention = Path.GetExtension(obj.ImageFile.FileName);
                    fileName = fileName + DateTime.Now.ToString("yymmssfff") + extention;
                    obj.emp_img = "/Emp_Images/" + fileName;
                    fileName = Path.Combine(Server.MapPath("~/Emp_Images/"), fileName);
                    obj.ImageFile.SaveAs(fileName);


                    SqlCommand sc = new SqlCommand("sp_post", conn);
                    sc.CommandType = CommandType.StoredProcedure;
                    sc.Parameters.AddWithValue("@emp_name", obj.emp_name);
                    sc.Parameters.AddWithValue("@emp_dob", obj.emp_dob);
                    sc.Parameters.AddWithValue("@emp_email", obj.emp_email);
                    sc.Parameters.AddWithValue("@emp_img", obj.emp_img);

                    conn.Open();
                    int i = sc.ExecuteNonQuery();
                    conn.Close();
                    if (i > 0)
                    {
                        RedirectToAction("Create");
                        TempData["success_msg"] = "Employee Successfully Added";
                    }
                    else
                    {
                        return View("Create");

                        TempData["msg"] = "Something Error While Inserting";
                    }
                   
                }


                else
                {
                    string fileName = Path.GetFileNameWithoutExtension(obj.ImageFile.FileName);
                    string extention = Path.GetExtension(obj.ImageFile.FileName);
                    fileName = fileName + DateTime.Now.ToString("yymmssfff") + extention;
                    obj.emp_img = "/Emp_Images/" + fileName;
                    fileName = Path.Combine(Server.MapPath("~/Emp_Images/"), fileName);
                    obj.ImageFile.SaveAs(fileName);

                    string query = "sp_put";

                    SqlCommand sc = new SqlCommand(query, conn);
                    sc.CommandType = CommandType.StoredProcedure;
                    sc.Parameters.AddWithValue("@emp_id", obj.emp_id);
                    sc.Parameters.AddWithValue("@emp_name", obj.emp_name);
                    sc.Parameters.AddWithValue("@emp_dob", obj.emp_dob);
                    sc.Parameters.AddWithValue("@emp_email", obj.emp_email);
                    sc.Parameters.AddWithValue("@emp_img", obj.emp_img);

                    conn.Open();
                    int i = sc.ExecuteNonQuery();
                    conn.Close();
                    if (i > 0)
                    {
                        return RedirectToAction("Create");
                        TempData["success_msg"] = "Employee Successfully Updated";
                    }
                }
                return View("Create");
            }
            catch (Exception ex)
            {
                TempData["msg"] = "Error:" + ex;
                return View("Create");
                
            }
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {

            try
            {
                SqlCommand sc = new SqlCommand("sp_get", conn);
                sc.CommandType = CommandType.StoredProcedure;
                sc.Parameters.AddWithValue("@emp_id", id);
                conn.Open();
                Emp_Model obj = new Emp_Model();
                SqlDataReader sdr = sc.ExecuteReader();

                while (sdr.Read())
                {
                    obj = new Emp_Model
                    {

                        emp_id = Convert.ToInt32(sdr["emp_id"]),
                        emp_name = sdr["emp_name"].ToString(),
                        emp_dob = sdr["emp_dob"].ToString(),
                        emp_email = sdr["emp_email"].ToString(),
                        emp_img = sdr["emp_img"].ToString()

                    };
                }
                conn.Close();
                return View("Create", obj);
            }
            catch (Exception ex)
            {
                TempData["msg"] = "Error:" + ex;
                return View("Create");
            }

        }
        public ActionResult Delete(int id)
        {
            try
            {
                SqlCommand sc = new SqlCommand("sp_delete", conn);
                sc.CommandType = CommandType.StoredProcedure;
                sc.Parameters.AddWithValue("@emp_id", id);
                conn.Open();
                int i = sc.ExecuteNonQuery();
                conn.Close();
                TempData["success_msg"] = "Successfully Removed";
                return View("Create");
            }catch(Exception ex)
            {
                TempData["msg"] = "Error:" + ex;
                return View("Create");

            }
        }
    }
}