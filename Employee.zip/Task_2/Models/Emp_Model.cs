﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Task_2.Models
{
    public class Emp_Model
    {
        
        public int emp_id { get; set; }
        [StringLength(50)]
        [Required(ErrorMessage="Enter Your Name.")]
        public string emp_name { get; set; }

        [Required(ErrorMessage = "Enter Your DOB.")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public string emp_dob { get; set; }

        [Required(ErrorMessage = "Enter Your EmailID")]
       // [RegularExpression(@"^[\w-\._\+%]+@(?:[\w-]+\.)+[\w]{2,6}$", ErrorMessage = "Please enter a valid email address")]
        [EmailAddress]
        public string emp_email { get; set; }

        [Required(ErrorMessage = "Upload Your Image.")]
        public string emp_img { get; set; }
        public HttpPostedFileBase ImageFile { get; set; }
    }
}